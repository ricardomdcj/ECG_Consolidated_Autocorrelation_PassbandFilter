//
// Student License - for use by students to meet course requirements and
// perform academic research at degree granting institutions only.  Not
// for government, commercial, or other organizational use.
//
// _coder_passabanda_info.h
//
// Code generation for function 'passabanda'
//

#ifndef _CODER_PASSABANDA_INFO_H
#define _CODER_PASSABANDA_INFO_H

// Include files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
// End of code generation (_coder_passabanda_info.h)
