//
// Student License - for use by students to meet course requirements and
// perform academic research at degree granting institutions only.  Not
// for government, commercial, or other organizational use.
//
// passabanda_terminate.cpp
//
// Code generation for function 'passabanda_terminate'
//

// Include files
#include "passabanda_terminate.h"

// Function Definitions
void passabanda_terminate()
{
}

// End of code generation (passabanda_terminate.cpp)
