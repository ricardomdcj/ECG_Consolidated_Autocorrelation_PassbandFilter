//
// Student License - for use by students to meet course requirements and
// perform academic research at degree granting institutions only.  Not
// for government, commercial, or other organizational use.
//
// passabanda_types.h
//
// Code generation for function 'passabanda'
//

#ifndef PASSABANDA_TYPES_H
#define PASSABANDA_TYPES_H

// Include files
#include "rtwtypes.h"

#endif
// End of code generation (passabanda_types.h)
