//
// Student License - for use by students to meet course requirements and
// perform academic research at degree granting institutions only.  Not
// for government, commercial, or other organizational use.
//
// passabanda_internal_types.h
//
// Code generation for function 'passabanda'
//

#ifndef PASSABANDA_INTERNAL_TYPES_H
#define PASSABANDA_INTERNAL_TYPES_H

// Include files
#include "passabanda_types.h"
#include "rtwtypes.h"

// Type Definitions
struct struct_T {
  int a[7];
  int b[7];
};

#endif
// End of code generation (passabanda_internal_types.h)
