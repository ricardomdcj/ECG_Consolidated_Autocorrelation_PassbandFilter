//
// Student License - for use by students to meet course requirements and
// perform academic research at degree granting institutions only.  Not
// for government, commercial, or other organizational use.
//
// passabanda.h
//
// Code generation for function 'passabanda'
//

#ifndef PASSABANDA_H
#define PASSABANDA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void passabanda(const double OrigECG[5000], double LPassDataFile[5000]);

#endif
// End of code generation (passabanda.h)
