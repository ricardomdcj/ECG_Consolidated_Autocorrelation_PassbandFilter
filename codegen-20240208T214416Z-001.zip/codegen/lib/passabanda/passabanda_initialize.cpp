//
// Student License - for use by students to meet course requirements and
// perform academic research at degree granting institutions only.  Not
// for government, commercial, or other organizational use.
//
// passabanda_initialize.cpp
//
// Code generation for function 'passabanda_initialize'
//

// Include files
#include "passabanda_initialize.h"

// Function Definitions
void passabanda_initialize()
{
}

// End of code generation (passabanda_initialize.cpp)
