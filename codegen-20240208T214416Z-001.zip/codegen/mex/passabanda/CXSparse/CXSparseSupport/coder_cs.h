/* Copyright 2020 The MathWorks, Inc. */

#ifndef CODER_CS_H
#define CODER_CS_H

#ifndef CS_COMPLEX
#define CS_COMPLEX
#endif

#include "cs.h"

#endif
