/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * passabanda_data.c
 *
 * Code generation for function 'passabanda_data'
 *
 */

/* Include files */
#include "passabanda_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;

emlrtContext emlrtContextGlobal = {
    true,                                                /* bFirstTime */
    false,                                               /* bInitialized */
    131643U,                                             /* fVersionInfo */
    NULL,                                                /* fErrorFunction */
    "passabanda",                                        /* fFunctionName */
    NULL,                                                /* fRTCallStack */
    false,                                               /* bDebugMode */
    {497312255U, 2566552405U, 2553285182U, 2715458501U}, /* fSigWrd */
    NULL                                                 /* fSigMem */
};

covrtInstance emlrtCoverageInstance;

/* End of code generation (passabanda_data.c) */
